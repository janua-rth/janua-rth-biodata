(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const audio = $('#audioEngine');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fmt = s => isFinite(s) ? Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0') : '--:--';
  const store = {
    get(k) { try { return +localStorage.getItem(k) || 0; } catch { return 0; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch {} }
  };

  /* ===== 1. SENTER (ikut jari/kursor) + mode lights-out ===== */
  const glow = Object.assign(document.createElement('div'), { className: 'fx-glow' });
  const dark = Object.assign(document.createElement('div'), { className: 'fx-dark' });
  document.body.append(glow, dark);
  let hideT;
  addEventListener('pointermove', e => {
    glow.style.transform = `translate(${e.clientX}px,${e.clientY}px)`;
    glow.style.opacity = 1;
    dark.style.setProperty('--mx', e.clientX + 'px');
    dark.style.setProperty('--my', e.clientY + 'px');
    clearTimeout(hideT);
    if (e.pointerType !== 'mouse') hideT = setTimeout(() => glow.style.opacity = 0, 700);
  });

  /* ===== 2. FOTO PROFIL: tekan = ledakan cahaya ===== */
  const wrap = $('.avatar-wrap');
  const toast = Object.assign(document.createElement('div'), { className: 'fx-toast' });
  document.body.appendChild(toast);
  const msgs = [
    'Cahaya menemukanmu.',
    'Jangan tersesat dalam gelap.',
    'Kamu masih di sini.',
    'Terus tekan. Ada yang tersembunyi.',
    'Sedikit lagi.',
    'Satu lagi...'
  ];
  let clicks = 0, toastT;
  function say(t) {
    toast.textContent = t;
    toast.classList.add('show');
    clearTimeout(toastT);
    toastT = setTimeout(() => toast.classList.remove('show'), 2200);
  }
  function burst() {
    wrap.classList.remove('pop');
    void wrap.offsetWidth;
    wrap.classList.add('pop');
    for (let i = 0; i < 2; i++) {
      const r = document.createElement('i');
      r.className = 'fx-ring';
      r.style.animationDelay = i * 0.15 + 's';
      wrap.appendChild(r);
      setTimeout(() => r.remove(), 1500);
    }
    const n = reduce ? 0 : 16;
    for (let i = 0; i < n; i++) {
      const p = document.createElement('i');
      const a = Math.PI * 2 * i / n + Math.random() * 0.4, d = 70 + Math.random() * 60;
      p.className = 'fx-spark';
      p.style.setProperty('--x', Math.cos(a) * d + 'px');
      p.style.setProperty('--y', Math.sin(a) * d + 'px');
      wrap.appendChild(p);
      setTimeout(() => p.remove(), 1000);
    }
    if (navigator.vibrate) navigator.vibrate(25);
    clicks++;
    if (clicks % 7 === 0) {
      const off = document.body.classList.toggle('lights-out');
      say(off ? 'LIGHTS OUT. Gerakkan jarimu untuk mencari cahaya.' : 'Lampu menyala kembali.');
    } else {
      say(msgs[(clicks - 1) % msgs.length]);
    }
  }
  if (wrap) {
    wrap.setAttribute('role', 'button');
    wrap.setAttribute('aria-label', 'Tekan foto profil');
    wrap.tabIndex = 0;
    wrap.addEventListener('click', burst);
    wrap.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); burst(); } });
  }

  /* ===== 3. NAMA "TERDEKRIPSI" saat masuk ===== */
  const nameEl = $('.name');
  function decode() {
    if (!nameEl || reduce) return;
    const final = nameEl.textContent, chars = '▒░01/\\#', t0 = performance.now(), dur = 1100;
    (function step(now) {
      const p = Math.min((now - t0) / dur, 1), keep = Math.floor(final.length * p);
      nameEl.textContent = final.split('').map((c, i) => c === ' ' || i < keep ? c : chars[Math.random() * chars.length | 0]).join('');
      if (p < 1) requestAnimationFrame(step); else nameEl.textContent = final;
    })(t0);
  }
  $('#enterBtn')?.addEventListener('click', () => setTimeout(decode, 550));

  /* ===== 4. WAIT ROOM ===== */
  const sec = document.createElement('section');
  sec.className = 'section reveal';
  sec.innerHTML = `
    <h2 class="section-title">Wait Room</h2>
    <div class="wr-card">
      <div class="wr-head">
        <div class="wr-eq" id="wrEq"><b></b><b></b><b></b><b></b><b></b></div>
        <button class="wr-time" id="wrTime" title="Putar / jeda lagu"><span id="wrLeft">--:--</span><small>SISA LAGU</small></button>
      </div>
      <div class="wr-tabs">
        <button data-g="hunt" class="on">LIGHT HUNT</button>
        <button data-g="fly">FIREFLIES</button>
      </div>
      <div class="wr-stage">
        <canvas id="wrCanvas"></canvas>
        <div class="wr-hud"><span id="wrA"></span><span id="wrB"></span></div>
        <div class="wr-hint" id="wrHint"></div>
      </div>
    </div>`;
  const sections = document.querySelectorAll('#main .section');
  sections[sections.length - 1].before(sec); // sebelum "Contact Me"

  // hitung mundur + equalizer
  const left = $('#wrLeft'), eq = $('#wrEq');
  const tick = () => {
    left.textContent = audio.paused && !audio.currentTime ? 'PLAY ▶' : fmt(audio.duration - audio.currentTime);
    eq.classList.toggle('on', !audio.paused);
  };
  ['timeupdate', 'play', 'pause', 'loadedmetadata', 'ended'].forEach(ev => audio.addEventListener(ev, tick));
  $('#wrTime').addEventListener('click', () => $('#barPlayBtn').click());
  tick();

  // canvas
  const cv = $('#wrCanvas'), ctx = cv.getContext('2d');
  const hudA = $('#wrA'), hudB = $('#wrB'), hint = $('#wrHint');
  let W = 0, H = 0, mode = 'hunt', raf = 0, visible = false, last = performance.now();
  const ptr = { x: -99, y: -99 };
  let orb, found = 0, miss = 0, dust = [], rip = [];
  let flies = [], score = 0, timeLeft = 0, state = 'idle', best = store.get('fly-best');

  function size() {
    const dpr = Math.min(devicePixelRatio || 1, 2);
    W = cv.clientWidth; H = cv.clientHeight;
    cv.width = W * dpr; cv.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    dust = Array.from({ length: 90 }, () => ({ x: Math.random() * W, y: Math.random() * H, s: Math.random() * 2 + 1 }));
  }
  const rand = (a, b) => a + Math.random() * (b - a);
  const newOrb = () => orb = { x: rand(30, W - 30), y: rand(30, H - 40) };
  const newFly = () => ({ x: rand(20, W - 20), y: rand(30, H - 30), vx: rand(-.5, .5), vy: rand(-.5, .5), ph: rand(0, 6) });

  function setMode(m) {
    mode = m;
    document.querySelectorAll('.wr-tabs button').forEach(b => b.classList.toggle('on', b.dataset.g === m));
    rip = [];
    if (m === 'hunt') { found = 0; miss = 0; newOrb(); hint.textContent = 'GESER JARI UNTUK MENCARI, TAP UNTUK MENANGKAP'; }
    else { state = 'idle'; score = 0; flies = []; hint.textContent = ''; }
    hud();
  }
  function hud() {
    if (mode === 'hunt') { hudA.textContent = 'DITEMUKAN ' + found; hudB.textContent = 'MELESET ' + miss; }
    else { hudA.textContent = 'TERTANGKAP ' + score; hudB.textContent = (state === 'run' ? Math.ceil(timeLeft) + 'D · ' : '') + 'REKOR ' + best; }
  }

  function act() {
    if (mode === 'hunt') {
      const d = Math.hypot(ptr.x - orb.x, ptr.y - orb.y);
      rip.push({ x: ptr.x, y: ptr.y, t: 0 });
      if (d < 28) { found++; rip.push({ x: orb.x, y: orb.y, t: 0 }); newOrb(); ptr.x = ptr.y = -99; }
      else miss++;
      hud();
    } else if (state !== 'run') {
      state = 'run'; score = 0; timeLeft = 25; flies = Array.from({ length: 9 }, newFly); hud();
    } else {
      let hit = -1, bd = 1e9;
      flies.forEach((f, i) => { const d = Math.hypot(f.x - ptr.x, f.y - ptr.y); if (d < 26 && d < bd) { bd = d; hit = i; } });
      if (hit > -1) { rip.push({ x: flies[hit].x, y: flies[hit].y, t: 0 }); flies[hit] = newFly(); score++; hud(); }
    }
  }
  function setP(e) { const r = cv.getBoundingClientRect(); ptr.x = e.clientX - r.left; ptr.y = e.clientY - r.top; }
  cv.addEventListener('pointermove', setP);
  cv.addEventListener('pointerdown', e => { setP(e); act(); });
  document.querySelectorAll('.wr-tabs button').forEach(b => b.addEventListener('click', () => setMode(b.dataset.g)));

  function drawRipples(dt) {
    rip = rip.filter(r => (r.t += dt) < 700);
    rip.forEach(r => {
      ctx.strokeStyle = `rgba(255,255,255,${1 - r.t / 700})`;
      ctx.beginPath(); ctx.arc(r.x, r.y, r.t / 700 * 60, 0, 7); ctx.stroke();
    });
  }
  function glowDot(x, y, r, a) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(255,255,255,${a})`); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
  }
  function center(t1, t2) {
    ctx.fillStyle = '#ddd'; ctx.textAlign = 'center';
    ctx.font = '700 16px "Space Mono",monospace'; ctx.fillText(t1, W / 2, H / 2 - 4);
    ctx.fillStyle = '#666'; ctx.font = '11px "Space Mono",monospace'; ctx.fillText(t2, W / 2, H / 2 + 18);
  }

  function frame(now) {
    const dt = Math.min(now - last, 50); last = now;
    ctx.fillStyle = '#030303'; ctx.fillRect(0, 0, W, H);
    if (mode === 'hunt') {
      dust.forEach(d => {
        const a = 1 - Math.hypot(d.x - ptr.x, d.y - ptr.y) / 110;
        if (a > 0) { ctx.fillStyle = `rgba(255,255,255,${a * .5})`; ctx.fillRect(d.x, d.y, d.s, d.s); }
      });
      glowDot(ptr.x, ptr.y, 90, .18);
      const heat = Math.max(0, 1 - Math.hypot(ptr.x - orb.x, ptr.y - orb.y) / 200);
      if (heat > 0) glowDot(orb.x, orb.y, 10 + heat * 60 + Math.sin(now / 200) * 3 * heat, heat * .9);
      if (ptr.x > 0) hint.textContent = heat > .75 ? 'PANAS' : heat > .4 ? 'HANGAT' : heat > 0 ? 'DINGIN' : 'GELAP';
    } else {
      if (state === 'run') {
        timeLeft -= dt / 1000;
        if (timeLeft <= 0) { state = 'over'; if (score > best) { best = score; store.set('fly-best', best); } hud(); }
        else if (Math.ceil(timeLeft) !== Math.ceil(timeLeft + dt / 1000)) hud();
      }
      if (state !== 'idle') flies.forEach(f => {
        f.ph += dt / 300; f.x += f.vx * dt / 16; f.y += f.vy * dt / 16;
        if (f.x < 10 || f.x > W - 10) f.vx *= -1;
        if (f.y < 24 || f.y > H - 10) f.vy *= -1;
        f.vx += rand(-.02, .02); f.vy += rand(-.02, .02);
        f.vx = Math.max(-.7, Math.min(.7, f.vx)); f.vy = Math.max(-.7, Math.min(.7, f.vy));
        glowDot(f.x, f.y, 20, .35 + .35 * Math.sin(f.ph));
        ctx.fillStyle = '#fff'; ctx.fillRect(f.x - 1.5, f.y - 1.5, 3, 3);
      });
      if (state === 'idle') center('TAP UNTUK MULAI', 'TANGKAP KUNANG-KUNANG DALAM 25 DETIK');
      if (state === 'over') center('SKOR ' + score, 'TAP UNTUK MAIN LAGI');
    }
    drawRipples(dt);
    raf = visible && !document.hidden ? requestAnimationFrame(frame) : 0;
  }
  function run() { if (!raf && visible) { last = performance.now(); raf = requestAnimationFrame(frame); } }

  new IntersectionObserver(es => { visible = es[0].isIntersecting; if (visible && !cv.clientWidth) visible = false; if (visible && !W) { size(); setMode(mode); } run(); }).observe(sec);
  document.addEventListener('visibilitychange', run);
  addEventListener('resize', () => { size(); if (mode === 'hunt') newOrb(); });
  requestAnimationFrame(() => { size(); setMode('hunt'); });

  /* ===== 5. WRITING (gaya notes HP) =====
     GANTI isi tulisanmu di sini. Pisahkan paragraf dengan satu baris kosong. */
  const writings = [
    {
      title: 'Di Antara Pohon',
      date: '04 Okt 2026',
      text: `Hutan itu tidak pernah benar-benar gelap. Ada cahaya kecil yang memilih tetap tinggal di sela daun.

Aku belajar dari sana: terang tidak selalu datang besar. Kadang ia cuma sebesar kunang-kunang, dan itu sudah cukup untuk menemukan jalan pulang.`
    },
    {
      title: 'Tentang Bising',
      date: '28 Sep 2026',
      text: `Dunia ramai sekali hari ini. Notifikasi, suara, opini.

Aku mencari satu kalimat yang jujur di antara semuanya. Belum ku temukam, tapi aku masih mencari.`
    },
    {
      title: 'Surat untuk Diriku Nanti',
      date: '15 Sep 2026',
      text: `Kalau kamu membaca ini saat sedang lelah, berhenti sebentar. Tarik napas.

Kamu tidak harus selesai hari ini. Kamu hanya harus tidak menyerah pada cahaya.`
    }
  ];

  function openList() {
    const root = $('#wnRoot'); if (!root) return;
    root.innerHTML = '<input class="wn-search" type="search" placeholder="Cari tulisan" aria-label="Cari tulisan"><div class="wn-list"></div>';
    const list = root.querySelector('.wn-list'), inp = root.querySelector('input');
    const draw = () => {
      list.textContent = '';
      const q = inp.value.trim().toLowerCase();
      const items = writings.filter(w => (w.title + ' ' + w.text).toLowerCase().includes(q));
      if (!items.length) { list.innerHTML = '<div class="empty-state">TIDAK ADA TULISAN</div>'; return; }
      items.forEach(w => {
        const b = document.createElement('button'), t = document.createElement('span'), s = document.createElement('span');
        b.className = 'wn-item'; t.className = 'wn-title'; s.className = 'wn-sub';
        t.textContent = w.title;
        s.textContent = w.date + '   ' + w.text.split('\n')[0];
        b.append(t, s);
        b.addEventListener('click', () => openNote(w));
        list.appendChild(b);
      });
    };
    inp.addEventListener('input', draw);
    draw();
  }
  function openNote(w) {
    const root = $('#wnRoot'); if (!root) return;
    root.textContent = '';
    const back = document.createElement('button');
    back.className = 'wn-back'; back.textContent = '‹ Semua tulisan';
    back.addEventListener('click', openList);
    const art = document.createElement('article'), h = document.createElement('h4'), d = document.createElement('time');
    art.className = 'wn-read'; h.textContent = w.title; d.textContent = w.date;
    art.append(h, d);
    w.text.split(/\n\s*\n/).forEach(p => { const el = document.createElement('p'); el.textContent = p.trim(); art.appendChild(el); });
    root.append(back, art);
    const m = $('#skillModal .modal'); if (m) m.scrollTop = 0;
  }

  const wCard = document.querySelector('.skill[data-skill="story"], .skill[data-skill="writing"]');
  if (wCard) {
    wCard.dataset.skill = 'writing';
    wCard.querySelector('span').textContent = 'WRITING';
    // berdiri sendiri: tidak bergantung pada skillContents bawaan
    wCard.addEventListener('click', () => {
      $('#modalTitle').textContent = 'WRITING';
      $('#modalBody').innerHTML = '<div id="wnRoot"></div>';
      $('#skillModal').classList.add('open');
      openList();
    });
  } else {
    console.warn('Kartu WRITING tidak ditemukan');
  }
})();
